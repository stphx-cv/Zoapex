// Sesion 15: caducidad de la sesion por inactividad (lado cliente).
// Reemplaza al JScript del Masterpage del material antiguo (SessionWarning /
// RedirectToWelcomePage), pero cuenta la inactividad real del usuario: cada vez
// que hay actividad (mouse, teclado, scroll) se reinician los temporizadores.
//
//   advertenciaMin -> minutos de inactividad para mostrar el aviso
//   timeoutMin     -> minutos de inactividad para cerrar la sesion

function iniciarControlSesion(advertenciaMin, timeoutMin) {
    var msAdvertencia = advertenciaMin * 60 * 1000;
    var msTimeout = timeoutMin * 60 * 1000;
    var tAdvertencia, tCierre;

    function programar() {
        clearTimeout(tAdvertencia);
        clearTimeout(tCierre);

        // aviso: la sesion esta por expirar
        tAdvertencia = setTimeout(function () {
            var faltan = timeoutMin - advertenciaMin;
            alert("Tu sesion va a expirar en " + faltan +
                  " minuto(s) por inactividad. Realiza alguna accion para mantenerla activa.");
        }, msAdvertencia);

        // cierre: la sesion expiro, se vuelve al Login
        tCierre = setTimeout(function () {
            alert("La sesion ha expirado. Seras redireccionado a la pagina de inicio de sesion.");
            window.location = "/Logout";
        }, msTimeout);
    }

    // cualquier actividad del usuario reinicia el conteo de inactividad
    ["mousemove", "mousedown", "keydown", "scroll", "touchstart"].forEach(function (ev) {
        document.addEventListener(ev, programar, { passive: true });
    });

    programar();   // arranca el conteo al cargar la pagina
}
