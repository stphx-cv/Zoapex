using Microsoft.AspNetCore.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Web_Sesion15.Modelos;

namespace Web_Sesion15.Datos;

// Capa de datos. Centraliza el acceso a la base de datos mediante EF Core.
// Las paginas NUNCA consultan la BD directamente: siempre llaman a estos metodos.
public class VentasRepositorio
{
    private readonly VentasLeonContext _ctx;

    public VentasRepositorio(VentasLeonContext ctx)
    {
        _ctx = ctx;
    }

    /* ================= SESION 12: CONSULTAS CON LINQ ================= */

    // Suma los importes de las facturas pendientes (estado 1) de un cliente.
    public async Task<decimal> CalcularDeudaClienteLinqAsync(string codigo)
    {
        decimal deuda = await (from f in _ctx.Facturas
                               join d in _ctx.DetalleFacturas on f.NumFac equals d.NumFac
                               where f.CodCli == codigo && f.EstFac == 1
                               select (decimal)(d.CanVen * d.PreVen)).SumAsync();
        return deuda;
    }

    // Lista las facturas de un cliente entre dos fechas (con su detalle).
    public async Task<List<Factura>> ListarFacturasLinqAsync(string codigo, DateTime ini, DateTime fin)
    {
        return await _ctx.Facturas
            .Include(f => f.Detalles)
            .Where(f => f.CodCli == codigo && f.FecFac >= ini && f.FecFac <= fin)
            .OrderBy(f => f.FecFac)
            .ToListAsync();
    }

    /* ============ SESION 12: PROCEDIMIENTOS ALMACENADOS ============ */

    public async Task<List<FacturaResumen>> ListarFacturasSpAsync(string codigo, DateTime ini, DateTime fin)
    {
        return await _ctx.FacturasResumen
            .FromSql($"EXEC usp_ListarFacturasClienteFechas {codigo}, {ini}, {fin}")
            .ToListAsync();
    }

    public async Task<decimal> CalcularDeudaClienteSpAsync(string codigo)
    {
        var pCodigo = new SqlParameter("@codigo", codigo);
        var pDeuda = new SqlParameter("@vdeuda", SqlDbType.Decimal)
        {
            Precision = 12,
            Scale = 2,
            Direction = ParameterDirection.Output
        };

        await _ctx.Database.ExecuteSqlRawAsync(
            "EXEC usp_DeudaCliente @codigo, @vdeuda OUTPUT", pCodigo, pDeuda);

        return pDeuda.Value == DBNull.Value ? 0 : (decimal)pDeuda.Value;
    }

    public async Task<Cliente?> BuscarClienteAsync(string codigo)
    {
        return await _ctx.Clientes.FirstOrDefaultAsync(c => c.CodCli == codigo);
    }

    /* ================= SESION 13 · EJEMPLO 1: PROVEEDORES (CRUD) ================= */

    // Lista proveedores; si el filtro viene vacio trae todos, si no filtra por razon social.
    public async Task<List<Proveedor>> ListarProveedoresAsync(string filtro)
    {
        filtro ??= "";
        return await _ctx.Proveedores
            .Where(p => filtro == "" || p.RazSocPrv.Contains(filtro))
            .OrderBy(p => p.RazSocPrv)
            .ToListAsync();
    }

    public async Task<Proveedor?> BuscarProveedorAsync(string codigo)
    {
        return await _ctx.Proveedores.FirstOrDefaultAsync(p => p.CodPrv == codigo);
    }

    public async Task InsertarProveedorAsync(Proveedor prov)
    {
        _ctx.Proveedores.Add(prov);
        await _ctx.SaveChangesAsync();
    }

    public async Task ActualizarProveedorAsync(Proveedor prov)
    {
        var p = await _ctx.Proveedores.FindAsync(prov.CodPrv);
        if (p == null) return;

        p.RazSocPrv = prov.RazSocPrv;
        p.RucPrv = prov.RucPrv;
        p.DirPrv = prov.DirPrv;
        p.CodDep = prov.CodDep;
        p.CodProv = prov.CodProv;
        p.CodDist = prov.CodDist;
        p.EstPrv = prov.EstPrv;

        await _ctx.SaveChangesAsync();   // EF Core detecta el cambio y hace el UPDATE
    }

    // Calcula el proximo codigo tipo P001, P002... a partir del ultimo registrado.
    public async Task<string> SiguienteCodigoProveedorAsync()
    {
        var ultimo = await _ctx.Proveedores
            .OrderByDescending(p => p.CodPrv)
            .Select(p => p.CodPrv)
            .FirstOrDefaultAsync();

        int n = 0;
        if (!string.IsNullOrEmpty(ultimo) && ultimo.Length > 1)
            int.TryParse(ultimo.Substring(1), out n);

        return "P" + (n + 1).ToString("000");
    }

    /* ================= SESION 13 · EJEMPLO 1: UBIGEO (cascada) ================= */

    public async Task<List<Departamento>> ListarDepartamentosAsync()
    {
        return await _ctx.Departamentos.OrderBy(d => d.NomDep).ToListAsync();
    }

    public async Task<List<Provincia>> ProvinciasPorDepartamentoAsync(string codDep)
    {
        return await _ctx.Provincias
            .Where(p => p.CodDep == codDep)
            .OrderBy(p => p.NomProv)
            .ToListAsync();
    }

    public async Task<List<Distrito>> DistritosPorProvinciaAsync(string codProv)
    {
        return await _ctx.Distritos
            .Where(d => d.CodProv == codProv)
            .OrderBy(d => d.NomDist)
            .ToListAsync();
    }

    /* ================= SESION 13 · EJEMPLO 2: CONSULTA DE VALOR ================= */

    // Total facturado por anio (no cuenta las anuladas). Alimenta la tabla y el grafico.
    public async Task<List<FacturacionAnual>> FacturacionAnualAsync()
    {
        return await (from f in _ctx.Facturas
                      join d in _ctx.DetalleFacturas on f.NumFac equals d.NumFac
                      where f.EstFac != 3
                      group (decimal)(d.CanVen * d.PreVen) by f.FecFac.Year into g
                      orderby g.Key
                      select new FacturacionAnual
                      {
                          Anio = g.Key,
                          Total = g.Sum()
                      }).ToListAsync();
    }

    /* ================= SESION 13 · EJEMPLO 3: PAGINACION ================= */

    // Total de facturas (para calcular cuantas paginas hay).
    public async Task<int> ContarFacturasAsync()
    {
        return await _ctx.Facturas.CountAsync();
    }

    // Paginacion LOCAL: EF Core traduce Skip/Take a OFFSET/FETCH en SQL Server.
    public async Task<List<Factura>> ListarFacturasLocalAsync(int pagina, int tam)
    {
        return await _ctx.Facturas
            .Include(f => f.Cliente)
            .Include(f => f.Vendedor)
            .Include(f => f.Detalles)
            .OrderBy(f => f.NumFac)
            .Skip((pagina - 1) * tam)   // salta las paginas anteriores
            .Take(tam)                  // toma solo los de esta pagina
            .ToListAsync();
    }

    // Paginacion con SP: la base de datos devuelve solo la pagina pedida.
    public async Task<List<FacturaPagina>> ListarFacturasSpPaginacionAsync(int pagina, int tam)
    {
        return await _ctx.FacturasPagina
            .FromSql($"EXEC usp_ListarFacturas_Paginacion {pagina}, {tam}")
            .ToListAsync();
    }

    /* ================= SESION 14 · EJEMPLO 1: ORDEN DE COMPRA (TRANSACCIONAL) ================= */

    // Productos activos de un proveedor (alimenta el combo del modal).
    public async Task<List<Producto>> ProductosPorProveedorAsync(string codPrv)
    {
        return await _ctx.Productos
            .Where(p => p.CodPrv == codPrv && p.EstPro == 1)
            .OrderBy(p => p.DesPro)
            .ToListAsync();
    }

    // Genera el siguiente correlativo de orden (OC0001, OC0002, ...).
    private async Task<string> SiguienteNumeroOrdenAsync()
    {
        var ultimo = await _ctx.OrdenesCompra
            .OrderByDescending(o => o.NumOco)
            .Select(o => o.NumOco)
            .FirstOrDefaultAsync();

        int n = (ultimo == null) ? 1 : int.Parse(ultimo.Substring(2)) + 1;
        return "OC" + n.ToString("D4");
    }

    // OPCION A) Guardar con EF Core dentro de una transaccion EXPLICITA.
    // La cabecera y todos los detalles se graban como una sola unidad (todo o nada).
    public async Task<string> RegistrarOrdenEfAsync(OrdenCompraNueva datos)
    {
        if (datos.Detalles.Count == 0)
            throw new InvalidOperationException("La orden no tiene detalle.");

        using var tx = await _ctx.Database.BeginTransactionAsync();
        try
        {
            var orden = new OrdenCompra
            {
                NumOco = await SiguienteNumeroOrdenAsync(),
                FecOco = DateTime.Now,
                CodPrv = datos.CodPrv,
                FecAte = datos.FecAte,
                EstOco = 1,
                UsuRegistro = "web",
                FecRegistro = DateTime.Now,
                Detalles = datos.Detalles.Select(d => new DetalleCompra
                {
                    CodPro = d.CodPro,
                    CanPed = d.CanPed
                }).ToList()
            };

            _ctx.OrdenesCompra.Add(orden);   // agrega cabecera + detalles
            await _ctx.SaveChangesAsync();    // los graba juntos
            await tx.CommitAsync();           // confirma la transaccion
            return orden.NumOco;
        }
        catch
        {
            await tx.RollbackAsync();         // ante cualquier error, no queda nada grabado
            throw;
        }
    }

    // OPCION B) Guardar con el PROCEDIMIENTO ALMACENADO transaccional.
    // Todo el detalle viaja en un solo parametro de tabla (TVP) y el SP maneja
    // BEGIN TRAN / COMMIT / ROLLBACK del lado de la base de datos.
    public async Task<string> RegistrarOrdenSpAsync(OrdenCompraNueva datos)
    {
        if (datos.Detalles.Count == 0)
            throw new InvalidOperationException("La orden no tiene detalle.");

        // se arma la tabla en memoria que se enviara como TVP
        var tabla = new DataTable();
        tabla.Columns.Add("Cod_pro", typeof(string));
        tabla.Columns.Add("Can_ped", typeof(int));
        foreach (var d in datos.Detalles)
            tabla.Rows.Add(d.CodPro, d.CanPed);

        var pProv = new SqlParameter("@Cod_prv", datos.CodPrv);
        var pFec = new SqlParameter("@Fec_ate", (object?)datos.FecAte ?? DBNull.Value);
        var pUsu = new SqlParameter("@Usuario", "web");
        var pDet = new SqlParameter("@Detalles", SqlDbType.Structured)
        {
            TypeName = "TVP_DetalleCompra",
            Value = tabla
        };
        var pNum = new SqlParameter("@Num_oco", SqlDbType.VarChar, 6)
        {
            Direction = ParameterDirection.Output
        };

        await _ctx.Database.ExecuteSqlRawAsync(
            "EXEC usp_RegistrarOrdenCompra @Cod_prv, @Fec_ate, @Usuario, @Detalles, @Num_oco OUTPUT",
            pProv, pFec, pUsu, pDet, pNum);

        return pNum.Value?.ToString() ?? "";
    }

    /* ================= SESION 14 · EJEMPLO 2: REPORTE EXCEL (EPPlus) ================= */

    // Consulta de valor: total pedido por producto en las ordenes de compra.
    public async Task<List<ProductoPedido>> ProductosMasPedidosAsync()
    {
        return await (from d in _ctx.DetallesCompra
                      join p in _ctx.Productos on d.CodPro equals p.CodPro
                      join pr in _ctx.Proveedores on p.CodPrv equals pr.CodPrv
                      group d.CanPed by new { p.CodPro, p.DesPro, pr.RazSocPrv } into g
                      orderby g.Sum() descending
                      select new ProductoPedido
                      {
                          CodPro = g.Key.CodPro,
                          DesPro = g.Key.DesPro,
                          Proveedor = g.Key.RazSocPrv,
                          TotalPedido = g.Sum()
                      }).ToListAsync();
    }

    /* ================= SESION 15: SEGURIDAD (ROLES Y USUARIOS) ================= */
    /* En Web Forms esto se resolvia con las clases Roles y Membership de System.Web.
       En ASP.NET Core usamos nuestro propio esquema y PasswordHasher para el hash.
       Toda la gestion de seguridad vive aqui, en la capa de datos. */

    // Instancia reutilizable para generar y verificar el hash de la clave.
    private static readonly PasswordHasher<Usuario> _hasher = new();

    public async Task<List<Rol>> ListarRolesAsync()
    {
        return await _ctx.Roles.OrderBy(r => r.NomRol).ToListAsync();
    }

    // Crea un rol nuevo si aun no existe (equivale a Roles.CreateRole del material antiguo).
    public async Task<bool> CrearRolAsync(string nombre)
    {
        nombre = (nombre ?? "").Trim();
        if (nombre == "" || await _ctx.Roles.AnyAsync(r => r.NomRol == nombre))
            return false;

        _ctx.Roles.Add(new Rol { NomRol = nombre });
        await _ctx.SaveChangesAsync();
        return true;
    }

    public async Task<List<UsuarioLista>> ListarUsuariosAsync()
    {
        // se traen los usuarios con sus roles y luego se arma la lista en memoria
        // (string.Join sobre una coleccion de navegacion no lo traduce EF Core a SQL).
        var usuarios = await _ctx.Usuarios
            .Include(u => u.Roles).ThenInclude(r => r.Rol)
            .OrderBy(u => u.Login)
            .ToListAsync();

        return usuarios.Select(u => new UsuarioLista
        {
            CodUsu = u.CodUsu,
            Login = u.Login,
            Nombre = u.Nombre,
            EstUsu = u.EstUsu,
            Roles = string.Join(", ", u.Roles.Select(r => r.Rol!.NomRol))
        }).ToList();
    }

    // Crea un usuario, hashea su clave y lo asigna a un rol
    // (equivale a Membership.CreateUser + Roles.AddUserToRole del material antiguo).
    public async Task<bool> CrearUsuarioAsync(UsuarioNuevo datos)
    {
        var login = (datos.Login ?? "").Trim();
        if (login == "" || string.IsNullOrWhiteSpace(datos.Clave))
            return false;

        if (await _ctx.Usuarios.AnyAsync(u => u.Login == login))
            return false;   // login ya usado

        var usuario = new Usuario
        {
            Login = login,
            Nombre = (datos.Nombre ?? "").Trim(),
            Email = datos.Email,
            EstUsu = 1,
            FecRegistro = DateTime.Now
        };
        // la clave se guarda como hash, nunca en texto plano
        usuario.Clave = _hasher.HashPassword(usuario, datos.Clave);
        usuario.Roles.Add(new UsuarioRol { CodRol = datos.CodRol });

        _ctx.Usuarios.Add(usuario);
        await _ctx.SaveChangesAsync();
        return true;
    }

    // Valida usuario + clave. Devuelve el usuario con sus roles, o null si no procede.
    public async Task<UsuarioAutenticado?> ValidarCredencialesAsync(string login, string clave)
    {
        var usuario = await _ctx.Usuarios
            .Include(u => u.Roles).ThenInclude(r => r.Rol)
            .FirstOrDefaultAsync(u => u.Login == login && u.EstUsu == 1);

        if (usuario == null) return null;

        // se compara la clave contra el hash guardado
        var resultado = _hasher.VerifyHashedPassword(usuario, usuario.Clave, clave);
        if (resultado == PasswordVerificationResult.Failed) return null;

        return new UsuarioAutenticado
        {
            Login = usuario.Login,
            Nombre = usuario.Nombre,
            Roles = usuario.Roles.Select(r => r.Rol!.NomRol).ToList()
        };
    }

    public async Task<bool> ExistenUsuariosAsync()
    {
        return await _ctx.Usuarios.AnyAsync();
    }

    public async Task<int> CodigoRolAsync(string nombre)
    {
        return await _ctx.Roles.Where(r => r.NomRol == nombre)
                               .Select(r => r.CodRol).FirstOrDefaultAsync();
    }
}
