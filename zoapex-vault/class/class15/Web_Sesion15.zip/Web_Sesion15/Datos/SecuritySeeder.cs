using Web_Sesion15.Modelos;

namespace Web_Sesion15.Datos;

// Siembra seguridad inicial: si no hay usuarios, crea 'admin' y 'operador' con sus
// roles, para poder iniciar sesion la primera vez. Los roles ya vienen del script
// VentasLeon_S15.sql; si faltaran, tambien se crean aqui.
public static class SecuritySeeder
{
    public static async Task SembrarAsync(VentasRepositorio repo)
    {
        // asegura los roles base
        await repo.CrearRolAsync("Administrador");
        await repo.CrearRolAsync("Operador");

        if (await repo.ExistenUsuariosAsync()) return;   // ya hay usuarios, no siembra

        int codAdmin = await repo.CodigoRolAsync("Administrador");
        int codOper = await repo.CodigoRolAsync("Operador");

        // usuario administrador (clave por defecto: Admin123)
        await repo.CrearUsuarioAsync(new UsuarioNuevo
        {
            Login = "admin",
            Clave = "Admin123",
            Nombre = "Administrador del sistema",
            Email = "admin@ventasleon.pe",
            CodRol = codAdmin
        });

        // usuario operador (clave por defecto: Oper123)
        await repo.CrearUsuarioAsync(new UsuarioNuevo
        {
            Login = "operador",
            Clave = "Oper123",
            Nombre = "Operador de ventas",
            Email = "operador@ventasleon.pe",
            CodRol = codOper
        });
    }
}
