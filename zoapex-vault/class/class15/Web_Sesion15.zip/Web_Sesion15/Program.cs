using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Web_Sesion15.Datos;
using Web_Sesion15.Modelos;

// Punto de entrada de la aplicacion. Aqui se registran los servicios
// y se arma la tuberia de peticiones (middlewares).
var builder = WebApplication.CreateBuilder(args);

// El AJAX de guardado (POST) envia el token antiforgery en una cabecera.
builder.Services.AddAntiforgery(o => o.HeaderName = "RequestVerificationToken");

// Se registra el DbContext de EF Core con la cadena de conexion de appsettings.json.
builder.Services.AddDbContext<VentasLeonContext>(opciones =>
    opciones.UseSqlServer(builder.Configuration.GetConnectionString("VentasLeon")));

// La capa de datos: expone las consultas y la gestion de seguridad (roles/usuarios).
builder.Services.AddScoped<VentasRepositorio>();

/* ---------------- SESION 15: seguridad basada en formularios y roles ----------------
   En Web Forms se configuraba en web.config (authentication mode="Forms", roleManager,
   membership). En ASP.NET Core la autenticacion se hace con cookies y la autorizacion
   con politicas por rol, todo declarado aqui. */

// Tiempo de caducidad de la sesion (en minutos), leido de appsettings.json.
int minutosSesion = builder.Configuration.GetValue<int>("Seguridad:TimeoutSesionMin");

// Autenticacion por cookie: reemplaza al viejo <authentication mode="Forms">.
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(opciones =>
    {
        opciones.LoginPath = "/Login";                       // formulario de inicio de sesion
        opciones.LogoutPath = "/Logout";
        opciones.AccessDeniedPath = "/AccesoDenegado";        // sin permiso para el recurso
        opciones.ExpireTimeSpan = TimeSpan.FromMinutes(minutosSesion);
        opciones.SlidingExpiration = true;                    // se renueva con cada actividad
    });

// Politicas por rol: reemplazan a las reglas <authorization> por carpeta del web.config.
builder.Services.AddAuthorization(opciones =>
{
    opciones.AddPolicy("EsAdministrador", p => p.RequireRole("Administrador"));
    opciones.AddPolicy("AdminUOperador", p => p.RequireRole("Administrador", "Operador"));
});

// Razor Pages + convenciones de autorizacion (equivalente al web.config de cada carpeta).
builder.Services.AddRazorPages(opciones =>
{
    var c = opciones.Conventions;
    // por defecto todo el sitio exige haber iniciado sesion...
    c.AuthorizeFolder("/");
    // ...salvo estas paginas publicas
    c.AllowAnonymousToPage("/Login");
    c.AllowAnonymousToPage("/AccesoDenegado");
    c.AllowAnonymousToPage("/Error");

    // reglas por rol (como los <allow roles=...> de cada carpeta del material antiguo)
    c.AuthorizePage("/Proveedores", "EsAdministrador");   // Mantenimientos -> solo Administrador
    c.AuthorizeFolder("/Seguridad", "EsAdministrador");   // Seguridad      -> solo Administrador
    c.AuthorizePage("/OrdenCompra", "EsAdministrador");   // Transacciones  -> solo Administrador
    c.AuthorizePage("/Reporte", "AdminUOperador");        // Consultas      -> Administrador u Operador
    c.AuthorizePage("/Consulta", "AdminUOperador");
    c.AuthorizePage("/Procedimiento", "AdminUOperador");
    c.AuthorizePage("/Ajax", "AdminUOperador");
    c.AuthorizePage("/Grafico", "AdminUOperador");
    c.AuthorizePage("/Paginacion", "AdminUOperador");
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();   // permite servir css y js desde wwwroot
app.UseRouting();

app.UseAuthentication();  // primero autentica (quien es)...
app.UseAuthorization();   // ...luego autoriza (que puede hacer)

app.MapRazorPages();

// Siembra la seguridad inicial (roles y usuarios por defecto) al arrancar.
using (var scope = app.Services.CreateScope())
{
    var repo = scope.ServiceProvider.GetRequiredService<VentasRepositorio>();
    await SecuritySeeder.SembrarAsync(repo);
}

app.Run();
