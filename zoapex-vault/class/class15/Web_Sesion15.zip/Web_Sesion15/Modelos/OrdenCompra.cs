using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Sesion15.Modelos;

// Cabecera de la orden de compra (Tb_Orden_Compra). Tiene muchos detalles.
[Table("Tb_Orden_Compra")]
public class OrdenCompra
{
    [Key]
    [Column("Num_oco")]
    public string NumOco { get; set; } = "";

    [Column("Fec_oco")]
    public DateTime FecOco { get; set; }

    [Column("Cod_prv")]
    public string CodPrv { get; set; } = "";

    [Column("Fec_ate")]
    public DateTime? FecAte { get; set; }

    [Column("Est_oco")]
    public int EstOco { get; set; }

    [Column("Usu_Registro")]
    public string? UsuRegistro { get; set; }

    [Column("Fec_Registro")]
    public DateTime FecRegistro { get; set; }

    // Relacion uno a muchos: una orden tiene varios detalles.
    public List<DetalleCompra> Detalles { get; set; } = new();

    // Navegacion al proveedor (solo lectura para mostrar la razon social).
    public Proveedor? Proveedor { get; set; }

    [NotMapped]
    public string EstadoTexto => EstOco switch
    {
        1 => "Registrada",
        2 => "Atendida",
        _ => "Anulada"
    };
}
