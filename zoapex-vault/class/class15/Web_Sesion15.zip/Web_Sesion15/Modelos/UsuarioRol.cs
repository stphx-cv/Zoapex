using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Sesion15.Modelos;

// Tabla puente usuario-rol (Tb_Usuario_Rol). Clave compuesta (Cod_usu + Cod_rol).
[Table("Tb_Usuario_Rol")]
public class UsuarioRol
{
    [Column("Cod_usu")]
    public int CodUsu { get; set; }

    [Column("Cod_rol")]
    public int CodRol { get; set; }

    public Usuario? Usuario { get; set; }
    public Rol? Rol { get; set; }
}
