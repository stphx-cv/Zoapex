using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Sesion15.Modelos;

// Usuario del sitio (Tb_Usuario). La clave se guarda hasheada, nunca en texto plano.
[Table("Tb_Usuario")]
public class Usuario
{
    [Key]
    [Column("Cod_usu")]
    public int CodUsu { get; set; }

    [Column("Login")]
    public string Login { get; set; } = "";

    // Hash de la contrasena (lo genera PasswordHasher en la capa de datos).
    [Column("Clave")]
    public string Clave { get; set; } = "";

    [Column("Nombre")]
    public string Nombre { get; set; } = "";

    [Column("Email")]
    public string? Email { get; set; }

    [Column("Est_usu")]
    public int EstUsu { get; set; }

    [Column("Fec_Registro")]
    public DateTime FecRegistro { get; set; }

    // Roles asignados (relacion muchos a muchos a traves de Tb_Usuario_Rol).
    public List<UsuarioRol> Roles { get; set; } = new();
}
