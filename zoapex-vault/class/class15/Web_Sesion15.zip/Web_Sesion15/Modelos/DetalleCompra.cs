using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Sesion15.Modelos;

// Detalle de la orden de compra. Clave compuesta (Num_oco + Cod_pro) en el DbContext.
[Table("Tb_Detalle_Compra")]
public class DetalleCompra
{
    [Column("Num_oco")]
    public string NumOco { get; set; } = "";

    [Column("Cod_pro")]
    public string CodPro { get; set; } = "";

    [Column("Can_ped")]
    public int CanPed { get; set; }

    public OrdenCompra? Orden { get; set; }
    public Producto? Producto { get; set; }
}
