using System.ComponentModel.DataAnnotations;

namespace Web_Sesion15.Modelos;

// Lo que envia el formulario Login.
public class LoginInput
{
    [Required(ErrorMessage = "Ingrese el usuario.")]
    public string Login { get; set; } = "";

    [Required(ErrorMessage = "Ingrese la contrasena.")]
    public string Clave { get; set; } = "";

    public bool Recordarme { get; set; }
}

// Resultado de validar credenciales: el usuario y sus roles (o null si falla).
public class UsuarioAutenticado
{
    public string Login { get; set; } = "";
    public string Nombre { get; set; } = "";
    public List<string> Roles { get; set; } = new();
}

// Lo que envia la pagina Seguridad para crear un usuario nuevo.
public class UsuarioNuevo
{
    public string Login { get; set; } = "";
    public string Clave { get; set; } = "";
    public string Nombre { get; set; } = "";
    public string? Email { get; set; }
    public int CodRol { get; set; }
}

// Fila para listar usuarios en la pagina Seguridad.
public class UsuarioLista
{
    public int CodUsu { get; set; }
    public string Login { get; set; } = "";
    public string Nombre { get; set; } = "";
    public string Roles { get; set; } = "";
    public int EstUsu { get; set; }
}
