namespace Web_Sesion15.Modelos;

// Lo que envia el navegador al grabar la orden (cabecera + lista de detalles).
public class OrdenCompraNueva
{
    public string CodPrv { get; set; } = "";
    public DateTime? FecAte { get; set; }
    public List<DetalleNuevo> Detalles { get; set; } = new();
}

public class DetalleNuevo
{
    public string CodPro { get; set; } = "";
    public int CanPed { get; set; }
}

// Fila del reporte Excel (Ejemplo 2): producto y total pedido en ordenes de compra.
public class ProductoPedido
{
    public string CodPro { get; set; } = "";
    public string DesPro { get; set; } = "";
    public string Proveedor { get; set; } = "";
    public int TotalPedido { get; set; }
}
