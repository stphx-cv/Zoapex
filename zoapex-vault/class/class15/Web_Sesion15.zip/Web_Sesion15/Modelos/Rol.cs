using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Sesion15.Modelos;

// Rol de seguridad (Tb_Rol). Agrupa permisos: Administrador, Operador, etc.
[Table("Tb_Rol")]
public class Rol
{
    [Key]
    [Column("Cod_rol")]
    public int CodRol { get; set; }

    [Column("Nom_rol")]
    public string NomRol { get; set; } = "";
}
