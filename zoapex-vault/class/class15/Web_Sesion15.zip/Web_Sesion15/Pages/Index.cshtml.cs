using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web_Sesion15.Pages;

public class IndexModel : PageModel
{
    public void OnGet() { }
}
