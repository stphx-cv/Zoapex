using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Web_Sesion15.Datos;
using Web_Sesion15.Modelos;

namespace Web_Sesion15.Pages;

// Ejemplo 2: consulta de valor (productos mas pedidos) mostrada en tabla
// y descargable en Excel con EPPlus.
public class ReporteModel : PageModel
{
    private readonly VentasRepositorio _repo;
    public ReporteModel(VentasRepositorio repo) { _repo = repo; }

    public List<ProductoPedido> Datos { get; set; } = new();

    public async Task OnGetAsync()
    {
        Datos = await _repo.ProductosMasPedidosAsync();
    }

    // ?handler=Excel -> genera el archivo .xlsx y lo devuelve para descargar
    public async Task<IActionResult> OnGetExcelAsync()
    {
        var datos = await _repo.ProductosMasPedidosAsync();

        // EPPlus 5+ exige indicar el contexto de licencia una sola vez.
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        using var paquete = new ExcelPackage();
        var hoja = paquete.Workbook.Worksheets.Add("Productos");

        // encabezado del reporte
        hoja.Cells["A1"].Value = "ISIL";
        hoja.Cells["A1"].Style.Font.Bold = true;
        hoja.Cells["A1"].Style.Font.Size = 14;
        hoja.Cells["B1:D1"].Merge = true;
        hoja.Cells["B1"].Value = "PRODUCTOS MAS PEDIDOS EN ORDENES DE COMPRA";
        hoja.Cells["B1"].Style.Font.Bold = true;
        hoja.Cells["B1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

        // titulos de columna (fila 3)
        string[] titulos = { "Codigo", "Producto", "Proveedor", "Total pedido" };
        for (int c = 0; c < titulos.Length; c++)
        {
            var celda = hoja.Cells[3, c + 1];
            celda.Value = titulos[c];
            celda.Style.Font.Bold = true;
            celda.Style.Fill.PatternType = ExcelFillStyle.Solid;
            celda.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.FromArgb(30, 136, 165)); // teal ISIL
            celda.Style.Font.Color.SetColor(System.Drawing.Color.White);
        }

        // filas de datos (desde la fila 4)
        int fila = 4;
        foreach (var d in datos)
        {
            hoja.Cells[fila, 1].Value = d.CodPro;
            hoja.Cells[fila, 2].Value = d.DesPro;
            hoja.Cells[fila, 3].Value = d.Proveedor;
            hoja.Cells[fila, 4].Value = d.TotalPedido;
            fila++;
        }

        hoja.Cells[fila, 1].Value = "Total registros: " + datos.Count;
        hoja.Cells[fila, 1, fila, 4].Style.Font.Italic = true;
        hoja.Cells[1, 1, fila, 4].AutoFitColumns();

        var bytes = paquete.GetAsByteArray();
        return File(bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "ProductosMasPedidos.xlsx");
    }
}
