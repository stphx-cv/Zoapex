using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Web_Sesion15.Datos;
using Web_Sesion15.Modelos;

namespace Web_Sesion15.Pages;

// Ejemplo 1: registro transaccional de orden de compra (maestro-detalle).
// Los combos se llenan por AJAX y el guardado se hace por POST con fetch.
public class OrdenCompraModel : PageModel
{
    private readonly VentasRepositorio _repo;
    public OrdenCompraModel(VentasRepositorio repo) { _repo = repo; }

    public void OnGet() { }

    // ?handler=Proveedores -> proveedores activos para el combo principal
    public async Task<IActionResult> OnGetProveedoresAsync()
    {
        var lista = await _repo.ListarProveedoresAsync("");
        var activos = lista.Where(p => p.EstPrv == 1)
                           .Select(p => new { p.CodPrv, p.RazSocPrv });
        return new JsonResult(activos);
    }

    // ?handler=Productos -> productos del proveedor elegido (para el modal)
    public async Task<IActionResult> OnGetProductosAsync(string prv)
    {
        var lista = await _repo.ProductosPorProveedorAsync(prv);
        return new JsonResult(lista.Select(p => new { p.CodPro, p.DesPro, p.PrePro }));
    }

    // POST ?handler=Guardar&modo=ef|sp -> graba la orden de forma transaccional
    public async Task<IActionResult> OnPostGuardarAsync([FromBody] OrdenCompraNueva datos, string modo)
    {
        if (datos == null || string.IsNullOrWhiteSpace(datos.CodPrv) || datos.Detalles.Count == 0)
            return new JsonResult(new { ok = false, msg = "Datos incompletos." });

        try
        {
            // se elige el camino segun el boton pulsado
            string numOco = (modo == "sp")
                ? await _repo.RegistrarOrdenSpAsync(datos)
                : await _repo.RegistrarOrdenEfAsync(datos);

            return new JsonResult(new { ok = true, numOco });
        }
        catch (Exception ex)
        {
            // si la transaccion se revirtio, no quedo nada grabado
            return new JsonResult(new { ok = false, msg = ex.Message });
        }
    }
}
