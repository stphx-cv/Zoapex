using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Web_Sesion15.Datos;
using Web_Sesion15.Modelos;

namespace Web_Sesion15.Pages;

// Formulario Login. Reemplaza al control Login "pre programado" de Web Forms:
// aqui validamos las credenciales contra la capa de datos y, si son correctas,
// firmamos la cookie de autenticacion con el nombre y los roles del usuario.
public class LoginModel : PageModel
{
    private readonly VentasRepositorio _repo;
    public LoginModel(VentasRepositorio repo) { _repo = repo; }

    [BindProperty]
    public LoginInput Entrada { get; set; } = new();

    public string? Mensaje { get; set; }
    public string? ReturnUrl { get; set; }

    public void OnGet(string? returnUrl = null)
    {
        ReturnUrl = returnUrl;
    }

    public async Task<IActionResult> OnPostAsync(string? returnUrl = null)
    {
        ReturnUrl = returnUrl;
        if (!ModelState.IsValid) return Page();

        var usuario = await _repo.ValidarCredencialesAsync(Entrada.Login, Entrada.Clave);
        if (usuario == null)
        {
            Mensaje = "Usuario o contrasena incorrectos.";
            return Page();
        }

        // se arman los datos de identidad: nombre + un claim por cada rol
        var claims = new List<Claim>
        {
            new(ClaimTypes.Name, usuario.Login),
            new("NombreCompleto", usuario.Nombre)
        };
        foreach (var rol in usuario.Roles)
            claims.Add(new Claim(ClaimTypes.Role, rol));

        var identidad = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var propiedades = new AuthenticationProperties { IsPersistent = Entrada.Recordarme };

        // se crea la cookie de autenticacion (equivale al FormsAuthentication de antes)
        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identidad),
            propiedades);

        return LocalRedirect(string.IsNullOrEmpty(returnUrl) ? "/Index" : returnUrl);
    }
}
