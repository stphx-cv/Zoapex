using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Web_Sesion15.Datos;
using Web_Sesion15.Modelos;

namespace Web_Sesion15.Pages.Seguridad;

// Lab 1: gestion de roles y usuarios (crear y listar). Solo el rol Administrador
// puede entrar aqui, por la convencion AuthorizeFolder("/Seguridad", "EsAdministrador").
public class IndexModel : PageModel
{
    private readonly VentasRepositorio _repo;
    public IndexModel(VentasRepositorio repo) { _repo = repo; }

    public List<Rol> Roles { get; set; } = new();
    public List<UsuarioLista> Usuarios { get; set; } = new();
    public string? Mensaje { get; set; }

    [BindProperty] public string NuevoRol { get; set; } = "";
    [BindProperty] public UsuarioNuevo NuevoUsuario { get; set; } = new();

    public async Task OnGetAsync() => await CargarAsync();

    public async Task<IActionResult> OnPostRolAsync()
    {
        bool ok = await _repo.CrearRolAsync(NuevoRol);
        Mensaje = ok ? "Rol creado." : "No se pudo crear el rol (vacio o repetido).";
        await CargarAsync();
        return Page();
    }

    public async Task<IActionResult> OnPostUsuarioAsync()
    {
        bool ok = await _repo.CrearUsuarioAsync(NuevoUsuario);
        Mensaje = ok ? "Usuario creado." : "No se pudo crear el usuario (login repetido o datos incompletos).";
        await CargarAsync();
        return Page();
    }

    private async Task CargarAsync()
    {
        Roles = await _repo.ListarRolesAsync();
        Usuarios = await _repo.ListarUsuariosAsync();
    }
}
