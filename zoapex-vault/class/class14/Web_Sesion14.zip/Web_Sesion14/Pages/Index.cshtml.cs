using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web_Sesion14.Pages;

public class IndexModel : PageModel
{
    public void OnGet() { }
}
