using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Sesion14.Modelos;

// Entidad que mapea la tabla Tb_Producto. Cada producto pertenece a un proveedor.
[Table("Tb_Producto")]
public class Producto
{
    [Key]
    [Column("Cod_pro")]
    public string CodPro { get; set; } = "";

    [Column("Des_pro")]
    public string DesPro { get; set; } = "";

    [Column("Pre_pro")]
    public decimal PrePro { get; set; }

    [Column("Stk_act")]
    public int StkAct { get; set; }

    [Column("Cod_prv")]
    public string CodPrv { get; set; } = "";

    [Column("Est_pro")]
    public int EstPro { get; set; }   // 1 activo, 0 inactivo
}
